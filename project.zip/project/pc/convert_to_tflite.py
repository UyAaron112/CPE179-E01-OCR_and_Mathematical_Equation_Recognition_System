# convert_to_tflite.py
# Run this on PC only — converts a trained OCR model to TFLite format
# for deployment on Raspberry Pi.
#
# Strategy:
#   Since TrOCR is a PyTorch model (not TensorFlow), we use a lightweight
#   CRNN (CNN + LSTM) built in TensorFlow/Keras trained on math symbol images.
#   This is more practical for TFLite deployment than converting TrOCR directly.
#
# Output: models/equation_model.tflite

import os
import numpy as np
import tensorflow as tf
from tensorflow import keras

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# Go up one level to project root
PROJECT_DIR = os.path.dirname(BASE_DIR)
MODEL_DIR = os.path.join(PROJECT_DIR, "models")
os.makedirs(MODEL_DIR, exist_ok=True)

# ─────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────

IMG_HEIGHT = 32       # Input image height (standard for CRNN OCR)
IMG_WIDTH  = 128      # Input image width
IMG_CHANNELS = 1      # Grayscale

# Characters the model can recognize
# Covers digits, common math operators, letters, LaTeX-style symbols
CHARSET = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ" \
          r"+-*/=()[]{}^_\frac\int\sum\sqrt. "
NUM_CLASSES = len(CHARSET) + 1  # +1 for CTC blank token

print(f"Character set size: {len(CHARSET)}")
print(f"Number of classes (with CTC blank): {NUM_CLASSES}")

# ─────────────────────────────────────────
# MODEL DEFINITION — Lightweight CRNN
# CNN feature extractor + Bidirectional LSTM + CTC output
# Designed to be small enough for Raspberry Pi
# ─────────────────────────────────────────

def build_crnn(img_height, img_width, img_channels, num_classes):
    """
    Build a lightweight CRNN model for OCR.
    Input shape: (batch, height, width, channels)
    Output shape: (batch, time_steps, num_classes)
    """
    inputs = keras.Input(shape=(img_height, img_width, img_channels), name="image_input")

    # ── CNN Feature Extractor ──
    x = keras.layers.Conv2D(32, (3, 3), padding="same", activation="relu")(inputs)
    x = keras.layers.MaxPooling2D((2, 2))(x)

    x = keras.layers.Conv2D(64, (3, 3), padding="same", activation="relu")(x)
    x = keras.layers.MaxPooling2D((2, 2))(x)

    x = keras.layers.Conv2D(128, (3, 3), padding="same", activation="relu")(x)
    x = keras.layers.MaxPooling2D((2, 1))(x)  # Only pool height, keep width

    # ── Reshape for RNN ──
    # After pooling: height reduced, width is the time dimension
    new_shape = (img_width // 4, (img_height // 8) * 128)
    x = keras.layers.Reshape(target_shape=new_shape)(x)

    x = keras.layers.Dense(64, activation="relu")(x)
    x = keras.layers.Dropout(0.25)(x)

    # ── Bidirectional LSTM ──
    x = keras.layers.Bidirectional(keras.layers.LSTM(128, return_sequences=True))(x)
    x = keras.layers.Bidirectional(keras.layers.LSTM(64, return_sequences=True))(x)

    # ── Output layer ──
    outputs = keras.layers.Dense(num_classes, activation="softmax", name="output")(x)

    model = keras.Model(inputs=inputs, outputs=outputs, name="CRNN_OCR")
    return model


# ─────────────────────────────────────────
# BUILD & SUMMARIZE
# ─────────────────────────────────────────

print("\nBuilding CRNN model...")
model = build_crnn(IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS, NUM_CLASSES)
model.summary()

# ─────────────────────────────────────────
# DATASET PREPARATION
# Loads images from input_images/ and pairs them with ground truth labels.
# Images must be named eq1.png, eq2.png, etc.
# Ground truth LaTeX strings are defined in GROUND_TRUTH below.
# ─────────────────────────────────────────

INPUT_DIR = os.path.join(PROJECT_DIR, "input_images")

# Ground truth LaTeX per image — update this as you add more images
GROUND_TRUTH = {
    "eq1": r"x^{2} + 2x + 1",
    "eq2": r"\frac{a}{b} + c = 0",
    "eq3": r"\int_{0}^{1} x \, dx",
}

# Training hyperparameters
EPOCHS     = 50
BATCH_SIZE = 2      # Small batch — you likely have few images; increase as dataset grows
VAL_SPLIT  = 0.2    # 20% of data used for validation
MAX_LABEL_LEN = 32  # Maximum character length of any label


def encode_label(text, charset):
    """Convert a LaTeX string into a list of integer indices."""
    return [charset.index(c) for c in text if c in charset]


def load_dataset(input_dir, ground_truth, charset, img_height, img_width):
    """
    Load all images and encode their labels.
    Returns:
        images : np.array of shape (N, img_height, img_width, 1)
        labels : list of encoded integer sequences
    """
    images = []
    labels = []

    for key, latex in ground_truth.items():
        path = os.path.join(input_dir, f"{key}.png")
        if not os.path.exists(path):
            print(f"[WARNING] {path} not found — skipping.")
            continue

        img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)
        if img is None:
            print(f"[WARNING] Cannot read {path} — skipping.")
            continue

        # Preprocess
        img = cv2.fastNlMeansDenoising(img, h=30)
        img = cv2.adaptiveThreshold(
            img, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 11, 2
        )
        img = cv2.resize(img, (img_width, img_height))
        img = img.astype(np.float32) / 255.0
        img = img.reshape(img_height, img_width, 1)

        encoded = encode_label(latex, charset)
        if len(encoded) == 0:
            print(f"[WARNING] Label for {key} has no encodable characters — skipping.")
            continue

        images.append(img)
        labels.append(encoded)
        print(f"  Loaded: {key}.png  →  {latex}  →  {encoded}")

    return np.array(images), labels


def augment_image(img):
    """
    Apply random augmentations to a single image to artificially expand
    the dataset. Useful when you only have a few equation images.
    Returns a list of augmented variants including the original.
    """
    variants = [img]

    # Slight Gaussian blur
    blurred = cv2.GaussianBlur(img, (3, 3), 0)
    variants.append(blurred.reshape(IMG_HEIGHT, IMG_WIDTH, 1).astype(np.float32) / 255.0)

    # Salt and pepper noise
    noisy = (img * 255).astype(np.uint8).reshape(IMG_HEIGHT, IMG_WIDTH)
    h, w = noisy.shape
    num_salt = int(0.01 * h * w)
    sy, sx = np.random.randint(0, h, num_salt), np.random.randint(0, w, num_salt)
    noisy[sy, sx] = 255
    py, px = np.random.randint(0, h, num_salt), np.random.randint(0, w, num_salt)
    noisy[py, px] = 0
    variants.append(noisy.reshape(IMG_HEIGHT, IMG_WIDTH, 1).astype(np.float32) / 255.0)

    # Low contrast
    low = cv2.convertScaleAbs((img * 255).astype(np.uint8), alpha=0.6, beta=0)
    variants.append(low.reshape(IMG_HEIGHT, IMG_WIDTH, 1).astype(np.float32) / 255.0)

    return variants


# ─────────────────────────────────────────
# CTC LOSS
# CTC (Connectionist Temporal Classification) is the standard loss
# for sequence recognition tasks like OCR where the alignment between
# input frames and output characters is unknown.
# ─────────────────────────────────────────

import cv2  # needed for augmentation and loading

def ctc_loss_fn(y_true, y_pred):
    """
    Compute CTC loss.
    y_pred shape : (batch, time_steps, num_classes)
    y_true shape : (batch, max_label_len) — padded with -1
    """
    batch_size  = tf.shape(y_pred)[0]
    time_steps  = tf.shape(y_pred)[1]

    # Input lengths — full sequence length for every sample
    input_length = tf.fill([batch_size, 1], time_steps)
    input_length = tf.cast(input_length, tf.int32)

    # Label lengths — count non-padding (-1) entries per sample
    label_length = tf.reduce_sum(
        tf.cast(tf.not_equal(y_true, -1), tf.int32),
        axis=1, keepdims=True
    )

    # Replace padding (-1) with 0 for CTC computation
    y_true_clean = tf.maximum(y_true, 0)

    loss = tf.keras.backend.ctc_batch_cost(
        y_true_clean,
        y_pred,
        input_length,
        label_length
    )
    return loss


# ─────────────────────────────────────────
# LOAD & AUGMENT DATA
# ─────────────────────────────────────────

print("\nLoading dataset from input_images/...")
images, labels = load_dataset(INPUT_DIR, GROUND_TRUTH, CHARSET, IMG_HEIGHT, IMG_WIDTH)

if len(images) == 0:
    print("[ERROR] No images loaded. Add equation images to input_images/ and update GROUND_TRUTH.")
    exit(1)

print(f"\nLoaded {len(images)} image(s). Applying augmentation...")

aug_images = []
aug_labels = []
for img, lbl in zip(images, labels):
    variants = augment_image(img)
    for v in variants:
        aug_images.append(v)
        aug_labels.append(lbl)

aug_images = np.array(aug_images)
print(f"Dataset size after augmentation: {len(aug_images)} samples")

# Pad labels to MAX_LABEL_LEN with -1 (padding token)
padded_labels = np.full((len(aug_labels), MAX_LABEL_LEN), -1, dtype=np.int32)
for i, lbl in enumerate(aug_labels):
    length = min(len(lbl), MAX_LABEL_LEN)
    padded_labels[i, :length] = lbl[:length]

# Train / validation split
split = max(1, int(len(aug_images) * (1 - VAL_SPLIT)))
X_train, X_val = aug_images[:split], aug_images[split:]
y_train, y_val = padded_labels[:split], padded_labels[split:]

print(f"Training samples  : {len(X_train)}")
print(f"Validation samples: {len(X_val)}")

# ─────────────────────────────────────────
# COMPILE & TRAIN
# ─────────────────────────────────────────

print("\nCompiling model...")
model.compile(
    optimizer=keras.optimizers.Adam(learning_rate=1e-3),
    loss=ctc_loss_fn
)

# Callbacks
callbacks = [
    # Save best model weights during training
    keras.callbacks.ModelCheckpoint(
        filepath=os.path.join(MODEL_DIR, "best_weights.keras"),
        monitor="val_loss",
        save_best_only=True,
        verbose=1
    ),
    # Reduce learning rate if val_loss stops improving
    keras.callbacks.ReduceLROnPlateau(
        monitor="val_loss",
        factor=0.5,
        patience=5,
        verbose=1,
        min_lr=1e-6
    ),
    # Stop early if no improvement after 10 epochs
    keras.callbacks.EarlyStopping(
        monitor="val_loss",
        patience=10,
        restore_best_weights=True,
        verbose=1
    ),
]

print(f"\nTraining for up to {EPOCHS} epochs (early stopping enabled)...\n")
history = model.fit(
    X_train, y_train,
    batch_size=BATCH_SIZE,
    epochs=EPOCHS,
    validation_data=(X_val, y_val) if len(X_val) > 0 else None,
    callbacks=callbacks,
    verbose=1
)

print("\nTraining complete!")
print(f"  Final train loss : {history.history['loss'][-1]:.4f}")
if "val_loss" in history.history:
    print(f"  Final val loss   : {history.history['val_loss'][-1]:.4f}")

# ─────────────────────────────────────────
# SAVE TRAINED KERAS MODEL
# ─────────────────────────────────────────

KERAS_MODEL_PATH = os.path.join(MODEL_DIR, "equation_model.keras")
print(f"\nSaving trained Keras model to: {KERAS_MODEL_PATH}")
model.save(KERAS_MODEL_PATH)

# ─────────────────────────────────────────
# CONVERT TO TFLITE — with INT8 Quantization
# INT8 reduces model size and speeds up inference on Pi
# ─────────────────────────────────────────

print("\nConverting to TFLite with INT8 quantization...")

def representative_dataset():
    """
    Feed real training images so INT8 quantization is calibrated accurately.
    Using real data here (instead of random) gives better Pi inference accuracy.
    """
    for img in aug_images[:min(100, len(aug_images))]:
        sample = img.reshape(1, IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS).astype(np.float32)
        yield [sample]

converter = tf.lite.TFLiteConverter.from_keras_model(model)

# Enable full INT8 quantization
converter.optimizations = [tf.lite.Optimize.DEFAULT]
converter.representative_dataset = representative_dataset
converter.target_spec.supported_ops = [tf.lite.OpsSet.TFLITE_BUILTINS_INT8]
converter.inference_input_type  = tf.uint8
converter.inference_output_type = tf.uint8

tflite_model = converter.convert()

TFLITE_PATH = os.path.join(MODEL_DIR, "equation_model.tflite")
with open(TFLITE_PATH, "wb") as f:
    f.write(tflite_model)

size_kb = os.path.getsize(TFLITE_PATH) / 1024
print(f"\nTFLite model saved to : {TFLITE_PATH}")
print(f"Model size            : {size_kb:.1f} KB")
print("\nConversion complete!")
print("Transfer models/equation_model.tflite to your Raspberry Pi.")

# ─────────────────────────────────────────
# SAVE CHARSET for use on Pi
# The Pi needs the same character mapping to decode predictions
# ─────────────────────────────────────────

CHARSET_PATH = os.path.join(MODEL_DIR, "charset.txt")
with open(CHARSET_PATH, "w") as f:
    f.write(CHARSET)
print(f"Charset saved to      : {CHARSET_PATH}")
print("Also transfer charset.txt to your Raspberry Pi.")