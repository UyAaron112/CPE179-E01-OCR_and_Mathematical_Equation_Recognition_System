# pipeline_pi.py
# Math Equation Recognition Pipeline — Raspberry Pi Deployment
# Uses tflite_runtime only (no TensorFlow, no transformers, no pix2tex)
#
# Install on Pi:
#   pip install tflite-runtime opencv-python-headless numpy pillow easyocr nltk
#
# Run:
#   python pipeline_pi.py --image /media/pi/USB/eq1.png

import os
import sys
import argparse
import time
import string
import numpy as np
import cv2
from PIL import Image

import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
nltk.download("stopwords", quiet=True)
nltk.download("punkt", quiet=True)

# Use tflite_runtime on Pi — much lighter than full TensorFlow
try:
    from tflite_runtime.interpreter import Interpreter
except ImportError:
    # Fallback if running on PC for testing
    import tensorflow as tf
    Interpreter = tf.lite.Interpreter
    print("[INFO] Using tensorflow.lite instead of tflite_runtime (PC mode)")

# ─────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────

BASE_DIR    = os.path.dirname(os.path.abspath(__file__))
PROJECT_DIR = os.path.dirname(BASE_DIR)

MODEL_PATH   = os.path.join(PROJECT_DIR, "models", "equation_model.tflite")
CHARSET_PATH = os.path.join(PROJECT_DIR, "models", "charset.txt")
RESULTS_DIR  = os.path.join(PROJECT_DIR, "results")
os.makedirs(RESULTS_DIR, exist_ok=True)

IMG_HEIGHT   = 32
IMG_WIDTH    = 128
IMG_CHANNELS = 1

# ─────────────────────────────────────────
# LOAD CHARSET
# ─────────────────────────────────────────

def load_charset(path):
    if not os.path.exists(path):
        raise FileNotFoundError(f"charset.txt not found at {path}. Transfer it from PC.")
    with open(path, "r") as f:
        charset = f.read()
    print(f"Charset loaded: {len(charset)} characters")
    return charset

# ─────────────────────────────────────────
# LOAD TFLITE MODEL
# ─────────────────────────────────────────

def load_tflite_model(model_path):
    if not os.path.exists(model_path):
        raise FileNotFoundError(
            f"TFLite model not found at {model_path}.\n"
            "Run convert_to_tflite.py on PC first, then transfer the .tflite file."
        )
    print(f"Loading TFLite model from: {model_path}")
    interpreter = Interpreter(model_path=model_path)
    interpreter.allocate_tensors()
    print("Model loaded and tensors allocated.\n")
    return interpreter

# ─────────────────────────────────────────
# PREPROCESSING
# Handles phone-captured images:
# - Uneven lighting from flash
# - Perspective distortion
# - Variable backgrounds
# ─────────────────────────────────────────

def preprocess_image(image_path):
    """
    Load and preprocess a phone-captured equation image for TFLite inference.
    Returns a numpy array of shape (1, IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS).
    """
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {image_path}")

    # 1. Grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # 2. Denoise — removes camera noise from phone sensor
    denoised = cv2.fastNlMeansDenoising(gray, h=30)

    # 3. Deskew — corrects slight tilt from handheld capture
    coords = np.column_stack(np.where(denoised < 200))
    if len(coords) > 0:
        angle = cv2.minAreaRect(coords)[-1]
        if angle < -45:
            angle = 90 + angle
        if abs(angle) > 0.5:  # Only deskew if tilt is significant
            h, w = denoised.shape
            M = cv2.getRotationMatrix2D((w // 2, h // 2), angle, 1.0)
            denoised = cv2.warpAffine(denoised, M, (w, h),
                                      flags=cv2.INTER_CUBIC,
                                      borderMode=cv2.BORDER_REPLICATE)

    # 4. Adaptive threshold — handles uneven lighting from flash
    thresh = cv2.adaptiveThreshold(
        denoised, 255,
        cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 11, 2
    )

    # 5. Resize to model input size
    resized = cv2.resize(thresh, (IMG_WIDTH, IMG_HEIGHT))

    # 6. Normalize to [0, 1] and reshape for model
    normalized = resized.astype(np.float32) / 255.0
    input_tensor = normalized.reshape(1, IMG_HEIGHT, IMG_WIDTH, IMG_CHANNELS)

    return input_tensor, resized  # also return resized for display

# ─────────────────────────────────────────
# TFLITE INFERENCE
# ─────────────────────────────────────────

def run_tflite_inference(interpreter, input_tensor):
    """Run inference using TFLite interpreter. Returns raw output array."""
    input_details  = interpreter.get_input_details()
    output_details = interpreter.get_output_details()

    # Handle INT8 quantization input scaling
    input_scale, input_zero_point = input_details[0]["quantization"]
    if input_details[0]["dtype"] == np.uint8:
        input_tensor = (input_tensor / input_scale + input_zero_point).astype(np.uint8)

    interpreter.set_tensor(input_details[0]["index"], input_tensor)

    start = time.time()
    interpreter.invoke()
    elapsed = time.time() - start

    output = interpreter.get_tensor(output_details[0]["index"])

    # Dequantize output if INT8
    output_scale, output_zero_point = output_details[0]["quantization"]
    if output_details[0]["dtype"] == np.uint8:
        output = (output.astype(np.float32) - output_zero_point) * output_scale

    return output, round(elapsed * 1000, 2)  # ms

# ─────────────────────────────────────────
# CTC DECODE
# Greedy decode — picks highest probability character per time step
# then collapses repeated characters and removes blanks
# ─────────────────────────────────────────

def ctc_greedy_decode(output, charset):
    """
    Decode CTC output to a string.
    output shape: (1, time_steps, num_classes)
    """
    predictions = np.argmax(output[0], axis=-1)  # (time_steps,)
    blank_idx = len(charset)                      # last index is CTC blank

    decoded = []
    prev = None
    for idx in predictions:
        if idx != blank_idx and idx != prev:
            if idx < len(charset):
                decoded.append(charset[idx])
        prev = idx

    return "".join(decoded)

# ─────────────────────────────────────────
# EASYOCR FALLBACK — plain text regions
# ─────────────────────────────────────────

def run_easyocr_fallback(image_path):
    """
    Use EasyOCR as a fallback for plain text regions in the image.
    Only loaded if needed to save memory on Pi.
    """
    try:
        import easyocr
        reader = easyocr.Reader(['en'], gpu=False)
        results = reader.readtext(image_path)
        if not results:
            return "", 0.0
        text = " ".join(r[1] for r in results)
        conf = float(np.mean([r[2] for r in results]))
        return text, round(conf, 3)
    except ImportError:
        return "easyocr not installed", 0.0

# ─────────────────────────────────────────
# NLTK POSTPROCESSING
# ─────────────────────────────────────────

stop_words = set(stopwords.words("english"))

def postprocess_text(text):
    """Tokenize and clean recognized text."""
    tokens = word_tokenize(text)
    tokens = [t.lower() for t in tokens]
    tokens = [t for t in tokens if t not in string.punctuation]
    tokens = [t for t in tokens if t not in stop_words]
    return tokens

# ─────────────────────────────────────────
# SAVE RESULTS
# ─────────────────────────────────────────

def save_results(image_name, tflite_output, easyocr_output, tokens, inference_ms):
    result_path = os.path.join(RESULTS_DIR, f"{image_name}_result.txt")
    with open(result_path, "w") as f:
        f.write(f"Image           : {image_name}\n")
        f.write(f"TFLite Output   : {tflite_output}\n")
        f.write(f"EasyOCR Output  : {easyocr_output}\n")
        f.write(f"Cleaned Tokens  : {tokens}\n")
        f.write(f"Inference Time  : {inference_ms} ms\n")
    print(f"Results saved to: {result_path}")

# ─────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Math Equation OCR — Raspberry Pi TFLite Pipeline"
    )
    parser.add_argument(
        "--image", type=str, required=True,
        help="Path to the phone-captured equation image (e.g. /media/pi/USB/eq1.png)"
    )
    parser.add_argument(
        "--easyocr", action="store_true",
        help="Also run EasyOCR as a fallback for plain text regions"
    )
    args = parser.parse_args()

    print("=" * 60)
    print("  Raspberry Pi — Math Equation Recognition Pipeline")
    print("=" * 60)

    # Load charset and model
    charset     = load_charset(CHARSET_PATH)
    interpreter = load_tflite_model(MODEL_PATH)

    # Preprocess image
    print(f"\nProcessing image: {args.image}")
    input_tensor, _ = preprocess_image(args.image)

    # TFLite inference
    print("Running TFLite inference...")
    output, inference_ms = run_tflite_inference(interpreter, input_tensor)
    tflite_text = ctc_greedy_decode(output, charset)

    print(f"\n{'─'*40}")
    print(f"TFLite Output    : {tflite_text}")
    print(f"Inference Time   : {inference_ms} ms")

    # Optional EasyOCR fallback
    easyocr_text = ""
    if args.easyocr:
        print("\nRunning EasyOCR fallback...")
        easyocr_text, conf = run_easyocr_fallback(args.image)
        print(f"EasyOCR Output   : {easyocr_text} (conf: {conf})")

    # NLTK postprocessing
    tokens = postprocess_text(tflite_text)
    print(f"Cleaned Tokens   : {tokens}")
    print(f"{'─'*40}\n")

    # Save results
    image_name = os.path.splitext(os.path.basename(args.image))[0]
    save_results(image_name, tflite_text, easyocr_text, tokens, inference_ms)

    print("Done!")


if __name__ == "__main__":
    main()